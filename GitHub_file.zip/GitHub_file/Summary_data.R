


rm(list = ls())


# DD_ms <- read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_ms_10000.csv")
# 100*table(DD_ms[,2])/1000; 100*table(DD_ms[,3])/1000; 100*table(DD_ms[,4])/1000


DD1 <- as.matrix(read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_1000.csv"))
DD2 <- as.matrix(read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_10000.csv"))



kekka1_0 <- cbind(DD1[,2:3]%*%c(1,0), DD1[,5:6]%*%c(1,0), DD1[,8:9]%*%c(1,0),DD1[,11:12]%*%c(1,0))
kekka1_10 <- cbind(DD1[,2:3]%*%c(1,10), DD1[,5:6]%*%c(1,10), DD1[,8:9]%*%c(1,10),DD1[,11:12]%*%c(1,10))
kekka1_20 <- cbind(DD1[,2:3]%*%c(1,20), DD1[,5:6]%*%c(1,20), DD1[,8:9]%*%c(1,20),DD1[,11:12]%*%c(1,20))

kekka2_0 <- cbind(DD2[,2:3]%*%c(1,0), DD2[,5:6]%*%c(1,0), DD2[,8:9]%*%c(1,0),DD2[,11:12]%*%c(1,0))
kekka2_10 <- cbind(DD2[,2:3]%*%c(1,10), DD2[,5:6]%*%c(1,10), DD2[,8:9]%*%c(1,10),DD2[,11:12]%*%c(1,10))
kekka2_20 <- cbind(DD2[,2:3]%*%c(1,20), DD2[,5:6]%*%c(1,20), DD2[,8:9]%*%c(1,20),DD2[,11:12]%*%c(1,20))



kk1 <- data.frame(tit1 = paste0("Proposed"),
                  tit2 = paste0("GIC-type"),
                  tit3 = paste0("CDE(0)"),
                  P1 = paste0(format(round(mean(kekka1_0[,1]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_0[,1]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_0[,1]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_0[,1])+(2-mean(kekka1_0[,1]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_0[,1]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_0[,1]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_0[,1]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_0[,1])+(2-mean(kekka2_0[,1]))^2),digits=3),nsmall=3))
)
kk2 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(10)"),
                  P1 = paste0(format(round(mean(kekka1_10[,1]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_10[,1]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_10[,1]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_10[,1])+(2-mean(kekka1_10[,1]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_10[,1]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_10[,1]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_10[,1]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_10[,1])+(2-mean(kekka2_10[,1]))^2),digits=3),nsmall=3))
)
kk3 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(20)"),
                  P1 = paste0(format(round(mean(kekka1_20[,1]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_20[,1]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_20[,1]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_20[,1])+(2-mean(kekka1_20[,1]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_20[,1]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_20[,1]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_20[,1]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_20[,1])+(2-mean(kekka2_20[,1]))^2),digits=3),nsmall=3))
)
kk4 <- data.frame(tit1 = paste0("Ordinary SMM"),
                  tit2 = paste0("AIC-type"),
                  tit3 = paste0("CDE(0)"),
                  P1 = paste0(format(round(mean(kekka1_0[,2]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_0[,2]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_0[,2]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_0[,2])+(2-mean(kekka1_0[,2]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_0[,2]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_0[,2]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_0[,2]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_0[,2])+(2-mean(kekka2_0[,2]))^2),digits=3),nsmall=3))
)
kk5 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(10)"),
                  P1 = paste0(format(round(mean(kekka1_10[,2]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_10[,2]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_10[,2]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_10[,2])+(2-mean(kekka1_10[,2]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_10[,2]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_10[,2]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_10[,2]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_10[,2])+(2-mean(kekka2_10[,2]))^2),digits=3),nsmall=3))
)
kk6 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(20)"),
                  P1 = paste0(format(round(mean(kekka1_20[,2]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_20[,2]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_20[,2]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_20[,2])+(2-mean(kekka1_20[,2]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_20[,2]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_20[,2]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_20[,2]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_20[,2])+(2-mean(kekka2_20[,2]))^2),digits=3),nsmall=3))
)
kk7 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0("GIC-type"),
                  tit3 = paste0("CDE(0)"),
                  P1 = paste0(format(round(mean(kekka1_0[,3]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_0[,3]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_0[,3]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_0[,3])+(2-mean(kekka1_0[,3]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_0[,3]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_0[,3]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_0[,3]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_0[,3])+(2-mean(kekka2_0[,3]))^2),digits=3),nsmall=3))
)
kk8 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(10)"),
                  P1 = paste0(format(round(mean(kekka1_10[,3]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_10[,3]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_10[,3]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_10[,3])+(2-mean(kekka1_10[,3]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_10[,3]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_10[,3]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_10[,3]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_10[,3])+(2-mean(kekka2_10[,3]))^2),digits=3),nsmall=3))
)
kk9 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(20)"),
                  P1 = paste0(format(round(mean(kekka1_20[,3]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_20[,3]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_20[,3]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_20[,3])+(2-mean(kekka1_20[,3]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_20[,3]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_20[,3]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_20[,3]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_20[,3])+(2-mean(kekka2_20[,3]))^2),digits=3),nsmall=3))
)
kk10 <- data.frame(tit1 = paste0("2SLS"),
                  tit2 = paste0("-"),
                  tit3 = paste0("CDE(0)"),
                  P1 = paste0(format(round(mean(kekka1_0[,4]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_0[,4]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_0[,4]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_0[,4])+(2-mean(kekka1_0[,4]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_0[,4]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_0[,4]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_0[,4]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_0[,4])+(2-mean(kekka2_0[,4]))^2),digits=3),nsmall=3))
)
kk11 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(10)"),
                  P1 = paste0(format(round(mean(kekka1_10[,4]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_10[,4]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_10[,4]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_10[,4])+(2-mean(kekka1_10[,4]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_10[,4]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_10[,4]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_10[,4]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_10[,4])+(2-mean(kekka2_10[,4]))^2),digits=3),nsmall=3))
)
kk12 <- data.frame(tit1 = paste0(""),
                  tit2 = paste0(""),
                  tit3 = paste0("CDE(20)"),
                  P1 = paste0(format(round(mean(kekka1_20[,4]),digits=3),nsmall=3)),
                  P2 = paste0(format(round(sd(kekka1_20[,4]),digits=3),nsmall=3)),
                  P3 = paste0(format(round(abs(100*(2-mean(kekka1_20[,4]))/2),digits=3),nsmall=3)),
                  P4 = paste0(format(round(sqrt(var(kekka1_20[,4])+(2-mean(kekka1_20[,4]))^2),digits=3),nsmall=3)),
                  P5 = paste0(format(round(mean(kekka2_20[,4]),digits=3),nsmall=3)),
                  P6 = paste0(format(round(sd(kekka2_20[,4]),digits=3),nsmall=3)),
                  P7 = paste0(format(round(abs(100*(2-mean(kekka2_20[,4]))/2),digits=3),nsmall=3)),
                  P8 = paste0(format(round(sqrt(var(kekka2_20[,4])+(2-mean(kekka2_20[,4]))^2),digits=3),nsmall=3))
)

kk <- rbind(kk1,kk2,kk3,kk4,kk5,kk6,kk7,kk8,kk9,kk10,kk11,kk12)

write.csv(kk, "G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/_output/hyo1.csv")



# ##Estimates of CDE
# ###MM=0; true=2
# kekka_0 <- cbind(DD[,2:3]%*%c(1,0), DD[,5:6]%*%c(1,0), DD[,8:9]%*%c(1,0),DD[,11:12]%*%c(1,0))
# apply(kekka_0,2,mean)
# apply(kekka_0,2,sd)
# 100*(rep(2,4)-apply(kekka_0,2,mean))/rep(2,4)
# sqrt(apply(kekka_0,2,var)+(apply(kekka_0,2,mean)-rep(2,4))^2)
# 
# 
# ###MM=10; true=2
# kekka_10 <- cbind(DD[,2:3]%*%c(1,10), DD[,5:6]%*%c(1,10), DD[,8:9]%*%c(1,10),DD[,11:12]%*%c(1,10))
# apply(kekka_10,2,mean)
# apply(kekka_10,2,sd)
# 100*(rep(2,4)-apply(kekka_10,2,mean))/rep(2,4)
# sqrt(apply(kekka_10,2,var)+(apply(kekka_10,2,mean)-rep(2,4))^2)
# 
# 
# ###MM=20; true=2
# kekka_20 <- cbind(DD[,2:3]%*%c(1,20), DD[,5:6]%*%c(1,20), DD[,8:9]%*%c(1,20),DD[,11:12]%*%c(1,20))
# apply(kekka_20,2,mean)
# apply(kekka_20,2,sd)
# 100*(rep(2,4)-apply(kekka_20,2,mean))/rep(2,4)
# sqrt(apply(kekka_20,2,var)+(apply(kekka_20,2,mean)-rep(2,4))^2)

