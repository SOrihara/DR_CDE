

rm(list = ls())

library(ggplot2)
library(patchwork)


DD1 <- as.matrix(read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_1000.csv"))
DD2 <- as.matrix(read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_10000.csv"))



kekka1_0 <- data.frame(c(DD1[,2:3]%*%c(1,0), DD1[,5:6]%*%c(1,0), DD1[,8:9]%*%c(1,0),DD1[,11:12]%*%c(1,0)))
kekka1_10 <- data.frame(c(DD1[,2:3]%*%c(1,10), DD1[,5:6]%*%c(1,10), DD1[,8:9]%*%c(1,10),DD1[,11:12]%*%c(1,10)))
kekka1_20 <- data.frame(c(DD1[,2:3]%*%c(1,20), DD1[,5:6]%*%c(1,20), DD1[,8:9]%*%c(1,20),DD1[,11:12]%*%c(1,20)))

kekka2_0 <- data.frame(c(DD2[,2:3]%*%c(1,0), DD2[,5:6]%*%c(1,0), DD2[,8:9]%*%c(1,0),DD2[,11:12]%*%c(1,0)))
kekka2_10 <- data.frame(c(DD2[,2:3]%*%c(1,10), DD2[,5:6]%*%c(1,10), DD2[,8:9]%*%c(1,10),DD2[,11:12]%*%c(1,10)))
kekka2_20 <- data.frame(c(DD2[,2:3]%*%c(1,20), DD2[,5:6]%*%c(1,20), DD2[,8:9]%*%c(1,20),DD2[,11:12]%*%c(1,20)))


names(kekka1_0) <- names(kekka1_10) <- names(kekka1_20) <- c("yy")
names(kekka2_0) <- names(kekka2_10) <- names(kekka2_20) <- c("yy")




name1_1000 <- data.frame(rep("n = 1000", 1000))
name1_10000 <- data.frame(rep("n = 10000", 1000))
Method_1 <- data.frame(rep("1: Proposed", 1000))
Method_2 <- data.frame(rep("2: Ordinary SMM: AIC-type", 1000))
Method_3 <- data.frame(rep("3: Ordinary SMM: GIC-type", 1000))
Method_4 <- data.frame(rep("4: 2SLS", 1000))


names(name1_1000) <- names(name1_10000) <- "name1"
names(Method_1) <- names(Method_2) <- names(Method_3) <- names(Method_4) <- "Method"


kekka_CDE0_ <- cbind(rbind(cbind(name1_1000, Method_1), cbind(name1_1000, Method_2), cbind(name1_1000, Method_3), cbind(name1_1000, Method_4),
                          cbind(name1_10000, Method_1), cbind(name1_10000, Method_2), cbind(name1_10000, Method_3), cbind(name1_10000, Method_4)),
                    rbind(kekka1_0, kekka2_0)
                    )

kekka_CDE0 <- subset(kekka_CDE0_, abs(kekka_CDE0_$yy)<5)

sum(abs(kekka_CDE0_$yy)>5)


kekka_CDE10_ <- cbind(rbind(cbind(name1_1000, Method_1), cbind(name1_1000, Method_2), cbind(name1_1000, Method_3), cbind(name1_1000, Method_4),
                           cbind(name1_10000, Method_1), cbind(name1_10000, Method_2), cbind(name1_10000, Method_3), cbind(name1_10000, Method_4)),
                     rbind(kekka1_10, kekka2_10)
                     )

kekka_CDE10 <- subset(kekka_CDE10_, abs(kekka_CDE10_$yy)<10)

sum(abs(kekka_CDE10_$yy)>10)



kekka_CDE20_ <- cbind(rbind(cbind(name1_1000, Method_1), cbind(name1_1000, Method_2), cbind(name1_1000, Method_3), cbind(name1_1000, Method_4),
                           cbind(name1_10000, Method_1), cbind(name1_10000, Method_2), cbind(name1_10000, Method_3), cbind(name1_10000, Method_4)),
                     rbind(kekka1_20, kekka2_20)
                     )

kekka_CDE20 <- subset(kekka_CDE20_, abs(kekka_CDE20_$yy)<15)

sum(abs(kekka_CDE20_$yy)>15)



p1 <- ggplot(kekka_CDE0, aes(x = name1, y = yy, fill = Method, color = Method)) + 
  geom_boxplot() + geom_abline(intercept = 2, slope = 0, colour = "red", linetype = 5, linewidth = 1) +
  theme_bw() + xlab("") + ylab("Estimate")


p2 <- ggplot(kekka_CDE10, aes(x = name1, y = yy, fill = Method, color = Method)) + 
  geom_boxplot() + geom_abline(intercept = 2, slope = 0, colour = "red", linetype = 5, linewidth = 1) +
  theme_bw() + xlab("") + ylab("")


p3 <- ggplot(kekka_CDE20, aes(x = name1, y = yy, fill = Method, color = Method)) + 
  geom_boxplot() + geom_abline(intercept = 2, slope = 0, colour = "red", linetype = 5, linewidth = 1) +
  theme_bw() + xlab("") + ylab("")


p1 + p2 + p3 + 
  plot_layout(guides = "collect", nrow = 1, ncol = 3)　# 凡例を１つにまとめて1列で表示


