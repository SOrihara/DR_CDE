

rm(list = ls())

###Mediator selection Simulation 2 (realistic setting)###

library(MASS)
library(nleqslv)

set.seed(20240522)


##Necessary functions
ps_func <- function(xx) return(exp(xx)/(1+exp(xx)))



##Sample size and the number of iteration
nn <- 10000
KK <- 1000


kekka_SMM_AIC <- kekka_pro_AIC <- kekka_SMM_BIC <- kekka_pro_BIC <- matrix(0,nrow=KK,ncol=3)
kekka_JG <- matrix(0,nrow=KK,ncol=3)
mdl_AIC_pro <- mdl_BIC_pro <- mdl_AIC_SMM <- mdl_BIC_SMM <- rep(0,KK)


for(kk in 1:KK){
  
  ##Data-generating mechanism
  ###Covariates
  UU <- rnorm(nn,sd=sqrt(2))
  
  #cor(XX,UU); var(UU)
  
  
  ###Exposure
  AA <- rbinom(nn,1,0.5)
  
  
  ###Instrumental variables
  ZZ1 <- rgamma(nn,2,4); #hist(ZZ1)
  ZZ2 <- rgamma(nn,2,4)
  
  ###Mediator
  MM_ln <- 5*(-1+1*ZZ1+1*ZZ2+0.4*UU+0.4*AA*UU); #hist(MM_ln)
  MM <- 5*mapply(rbinom,1,4,ps_func(MM_ln))
  # MM <- abs(MM_ln)
  
  # summary(MM); sd(MM); table(MM); hist(MM,breaks=20)
  # cor(MM,cbind(AA,ZZ1,ZZ1+ZZ2,UU),method="spearman")

  
  ###Outcomes
  YY00 <- 42+0.2*UU+rnorm(nn,sd=sqrt(2)); #hist(YY00)
  YY <- 2*AA+0.4*MM+YY00; #hist(YY)

  # sum(YY00>48); sum(YY>48); sum(YY00>48)/nn; sum(YY>48)/nn
  # cor(YY,cbind(AA,UU),method="spearman")
  
  
  ##Estimation phase
  ###Propensity score estimator
  ps_AA <- mean(AA)
  
  
  ###Baseline outcome
  # YY_bl_coef <- lm(YY[AA==0&abs(MM)<5] ~ 1)$coef
  # YY_bl <- rep(1, nn)*YY_bl_coef
  YY_bl_coef <- lm(YY[AA==0&abs(MM)<5] ~ UU[AA==0&abs(MM)<5])$coef
  YY_bl <- cbind(1, UU)%*%YY_bl_coef
  
  
  ###Model construction
  ####True model is the combination of (tau1, tau2, and tau3).
  tau1 <- AA
  tau2 <- AA*MM
  tau3 <- MM
  
  
  tau_1 <- cbind(tau1,tau2); ZZ_1 <- cbind(1,ZZ1)
  tau_2 <- cbind(tau1,tau3); ZZ_2 <- cbind(1,ZZ2)
  tau_3 <- cbind(tau1,tau2,tau3); ZZ_3 <- cbind(1,ZZ1,ZZ2)
  
  
  lamb <- log(nn)
  # lamb <- nn^(0.2)
  
  Est_func <- function(tau, ZZ, select){
    # tau <- tau_1; ZZ <- ZZ_1; select=1
    
    ##Ordinal SMM estimator
    kk1 <- solve(t((AA-ps_AA)*tau)%*%tau)%*%t((AA-ps_AA)*tau)%*%c(YY-YY_bl)
    
    ##Proposed estimator
    kk2 <- solve(t((AA-ps_AA)*ZZ)%*%tau)%*%t((AA-ps_AA)*ZZ)%*%c(YY-YY_bl)
    
    
    ###From here, model selection criterion
    if(select==1){
      kk1_f <- c(kk1, 0); kk2_f <- c(kk2, 0)
    }else if(select==2){
      kk1_f <- c(kk1[1], 0, kk1[2]); kk2_f <- c(kk2[1], 0, kk2[2])
    }else{
      kk1_f <- kk1; kk2_f <- kk2
    }
    
    Sig_SMM_f <- t((AA-ps_AA)*tau*c(YY-tau_3%*%kk1_f-YY_bl))%*%((AA-ps_AA)*tau*c(YY-tau_3%*%kk1_f-YY_bl))
    Gam_SMM_f <- t((AA-ps_AA)*tau)%*%tau
    
    # Sig_pro_f <- t((AA-ps_AA)*ZZ*c(YY-tau_3%*%kk2_f-YY_bl))%*%((AA-ps_AA)*ZZ*c(YY-tau_3%*%kk2_f-YY_bl))
    # Gam_pro_f <- t((AA-ps_AA)*ZZ)%*%tau
    
    mat_smm <- sum(diag(Sig_SMM_f%*%t(solve(Gam_SMM_f))))
    # mat_pro <- sum(diag(solve(Gam_pro_f)%*%Sig_pro_f%*%t(solve(Gam_pro_f))%*%Gam_SMM_f))
    
    QAIC_SMM <- t((AA-ps_AA)*tau_3%*%kk1_f)%*%(tau_3%*%kk1_f)-2*t((AA-ps_AA)*tau_3%*%kk1_f)%*%c(YY-YY_bl)+2*mat_smm
    QBIC_SMM <- t((AA-ps_AA)*tau_3%*%kk1_f)%*%(tau_3%*%kk1_f)-2*t((AA-ps_AA)*tau_3%*%kk1_f)%*%c(YY-YY_bl)+lamb*mat_smm
    
    QAIC_pro <- t((AA-ps_AA)*tau_3%*%kk2_f)%*%(tau_3%*%kk2_f)-2*t((AA-ps_AA)*tau_3%*%kk2_f)%*%c(YY-YY_bl)+2*mat_smm
    QBIC_pro <- t((AA-ps_AA)*tau_3%*%kk2_f)%*%(tau_3%*%kk2_f)-2*t((AA-ps_AA)*tau_3%*%kk2_f)%*%c(YY-YY_bl)+lamb*mat_smm
    
    kekka_pro <- list(kk2,c(QAIC_pro,QBIC_pro))
    kekka_SMM <- list(kk1,c(QAIC_SMM,QBIC_SMM))
    
    names(kekka_pro) <- c("proposed:estimates","proposed:model selection criterions")
    names(kekka_SMM) <- c("SMM:estimates","SMM:model selection criterions")
    
    return(list(kekka_pro,kekka_SMM))
  }
  
  kk1 <- Est_func(tau_1,ZZ_1,select=1)
  kk2 <- Est_func(tau_2,ZZ_2,select=2)
  kk3 <- Est_func(tau_3,ZZ_3,select=3)
  
  mdl_AIC_pro[kk] <- AIC_pro <- order(c(kk1[[1]][[2]][1],kk2[[1]][[2]][1],kk3[[1]][[2]][1]))[1]
  mdl_BIC_pro[kk] <- BIC_pro <- order(c(kk1[[1]][[2]][2],kk2[[1]][[2]][2],kk3[[1]][[2]][2]))[1]
  
  mdl_AIC_SMM[kk] <- AIC_SMM <- order(c(kk1[[2]][[2]][1],kk2[[2]][[2]][1],kk3[[2]][[2]][1]))[1]
  mdl_BIC_SMM[kk] <- BIC_SMM <- order(c(kk1[[2]][[2]][2],kk2[[2]][[2]][2],kk3[[2]][[2]][2]))[1]
  
  
  if(AIC_pro==1) kekka_pro_AIC[kk,c(1,2)] <- kk1[[1]][[1]]
  else if(AIC_pro==2) kekka_pro_AIC[kk,c(1,3)] <- kk2[[1]][[1]]
  else if(AIC_pro==3) kekka_pro_AIC[kk,] <- kk3[[1]][[1]]
  
  if(AIC_SMM==1) kekka_SMM_AIC[kk,c(1,2)] <- kk1[[2]][[1]]
  else if(AIC_SMM==2) kekka_SMM_AIC[kk,c(1,3)] <- kk2[[2]][[1]]
  else if(AIC_SMM==3) kekka_SMM_AIC[kk,] <- kk3[[2]][[1]]
  
  
  if(BIC_pro==1) kekka_pro_BIC[kk,c(1,2)] <- kk1[[1]][[1]]
  else if(BIC_pro==2) kekka_pro_BIC[kk,c(1,3)] <- kk2[[1]][[1]]
  else if(BIC_pro==3) kekka_pro_BIC[kk,] <- kk3[[1]][[1]]
  
  if(BIC_SMM==1) kekka_SMM_BIC[kk,c(1,2)] <- kk1[[2]][[1]]
  else if(BIC_SMM==2) kekka_SMM_BIC[kk,c(1,3)] <- kk2[[2]][[1]]
  else if(BIC_SMM==3) kekka_SMM_BIC[kk,] <- kk3[[2]][[1]]
  
  
  ###J&G
  MM_h <- lm(MM~AA*ZZ1+AA*ZZ2)$fit
  
  tau_JG <- cbind(AA,AA*MM_h,MM_h)
  kekka_JG[kk,] <- c(solve(t(tau_JG)%*%tau_JG)%*%(t(tau_JG)%*%c(YY-YY_bl)))
  
  
  if(kk%%50==0) print(kk)
}


kekka <- data.frame(cbind(kekka_pro_BIC,kekka_SMM_AIC,kekka_SMM_BIC,kekka_JG))
kekka_ms <- data.frame(cbind(mdl_BIC_pro,mdl_AIC_SMM,mdl_BIC_SMM))


names(kekka) <- c("Proposed:AA","Proposed:AA*MM","Proposed:MM",
                  "SMM_AIC:AA","SMM_AIC:AA*MM","SMM_AIC:MM",
                  "SMM_BIC:AA","SMM_BIC:AA*MM","SMM_BIC:MM",
                  "JG:AA","JG:AA*MM","JG:MM"
                  )

names(kekka_ms) <- c("Proposed","SMM_AIC","SMM_BIC")


# write.csv(kekka,"G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_10000.csv")
# write.csv(kekka_ms,"G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_ms_10000.csv")


boxplot(kekka,ylim=c(0,10))
summary(kekka)
100*table(mdl_BIC_pro)/KK
100*table(mdl_AIC_SMM)/KK; 100*table(mdl_BIC_SMM)/KK



# ###Estimates of CDE
# ###MM=0; true=2
# kekka_0 <- cbind(kekka_pro_AIC[,1:2]%*%c(1,0),kekka_pro_BIC[,1:2]%*%c(1,0),
#                  kekka_SMM_AIC[,1:2]%*%c(1,0),kekka_SMM_BIC[,1:2]%*%c(1,0),kekka_JG[,1:2]%*%c(1,0))
# apply(kekka_0,2,mean)
# apply(kekka_0,2,sd)
# 100*(rep(2,5)-apply(kekka_0,2,mean))/rep(2,5)
# sqrt(apply(kekka_0,2,var)+(apply(kekka_0,2,mean)-rep(2,5))^2)
# 
# 
# kekka_10 <- cbind(kekka_pro_AIC[,1:2]%*%c(1,10),kekka_pro_BIC[,1:2]%*%c(1,10),
#                  kekka_SMM_AIC[,1:2]%*%c(1,10),kekka_SMM_BIC[,1:2]%*%c(1,10),kekka_JG[,1:2]%*%c(1,10))
# apply(kekka_10,2,mean)
# apply(kekka_10,2,sd)
# 100*(rep(2,5)-apply(kekka_10,2,mean))/rep(2,5)
# sqrt(apply(kekka_10,2,var)+(apply(kekka_10,2,mean)-rep(2,5))^2)



