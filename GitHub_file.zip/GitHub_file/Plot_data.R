

rm(list = ls())

library(ggplot2)
library(patchwork)


DD1 <- as.matrix(read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_1000.csv"))
DD2 <- as.matrix(read.csv("G:/マイドライブ/投稿予定原稿/2024DD_Mediator selection/_simulation/kekka_10000.csv"))



kekka1_0 <- cbind(DD1[,2:3]%*%c(1,0), DD1[,5:6]%*%c(1,0), DD1[,8:9]%*%c(1,0),DD1[,11:12]%*%c(1,0))
kekka1_10 <- cbind(DD1[,2:3]%*%c(1,10), DD1[,5:6]%*%c(1,10), DD1[,8:9]%*%c(1,10),DD1[,11:12]%*%c(1,10))
kekka1_20 <- cbind(DD1[,2:3]%*%c(1,20), DD1[,5:6]%*%c(1,20), DD1[,8:9]%*%c(1,20),DD1[,11:12]%*%c(1,20))

kekka2_0 <- cbind(DD2[,2:3]%*%c(1,0), DD2[,5:6]%*%c(1,0), DD2[,8:9]%*%c(1,0),DD2[,11:12]%*%c(1,0))
kekka2_10 <- cbind(DD2[,2:3]%*%c(1,10), DD2[,5:6]%*%c(1,10), DD2[,8:9]%*%c(1,10),DD2[,11:12]%*%c(1,10))
kekka2_20 <- cbind(DD2[,2:3]%*%c(1,20), DD2[,5:6]%*%c(1,20), DD2[,8:9]%*%c(1,20),DD2[,11:12]%*%c(1,20))



sd_0 <- c(apply(kekka1_0,2,sd), apply(kekka2_0,2,sd))
sd_10 <- c(apply(kekka1_10,2,sd), apply(kekka2_10,2,sd))
sd_20 <- c(apply(kekka1_20,2,sd), apply(kekka2_20,2,sd))

mean_0 <- c(100*abs(2-apply(kekka1_0,2,mean))/2, 100*abs(2-apply(kekka2_0,2,mean))/2)
mean_10 <- c(100*abs(2-apply(kekka1_10,2,mean))/2, 100*abs(2-apply(kekka2_10,2,mean))/2)
mean_20 <- c(100*abs(2-apply(kekka1_20,2,mean))/2, 100*abs(2-apply(kekka2_20,2,mean))/2)

rmse_0 <- c(sqrt(apply(kekka1_0,2,var)+(apply(kekka1_0,2,mean)-2)^2), sqrt(apply(kekka2_0,2,var)+(apply(kekka2_0,2,mean)-2)^2))
rmse_10 <- c(sqrt(apply(kekka1_10,2,var)+(apply(kekka1_10,2,mean)-2)^2), sqrt(apply(kekka2_10,2,var)+(apply(kekka2_10,2,mean)-2)^2))
rmse_20 <- c(sqrt(apply(kekka1_20,2,var)+(apply(kekka1_20,2,mean)-2)^2), sqrt(apply(kekka2_20,2,var)+(apply(kekka2_20,2,mean)-2)^2))



name1 <- data.frame(c("n = 1000", "n = 10000"))
name2 <- data.frame(c("1: Proposed", "2: Ordinary SMM: AIC-type", "3: Ordinary SMM: GIC-type", "4: 2SLS"))


plot_mean_0 <- cbind(merge(name2, name1), mean_0)
plot_mean_10 <- cbind(merge(name2, name1), mean_10)
plot_mean_20 <- cbind(merge(name2, name1), mean_20)
names(plot_mean_0) <- names(plot_mean_10) <- names(plot_mean_20) <- c("Method", "Sample_size", "Absolute_value_of_percent_bias")

plot_sd_0 <- cbind(merge(name2, name1), sd_0)
plot_sd_10 <- cbind(merge(name2, name1), sd_10)
plot_sd_20 <- cbind(merge(name2, name1), sd_20)
names(plot_sd_0) <- names(plot_sd_10) <- names(plot_sd_20) <- c("Method", "Sample_size", "ESE")

plot_rmse_0 <- cbind(merge(name2, name1), rmse_0)
plot_rmse_10 <- cbind(merge(name2, name1), rmse_10)
plot_rmse_20 <- cbind(merge(name2, name1), rmse_20)
names(plot_rmse_0) <- names(plot_rmse_10) <- names(plot_rmse_20) <- c("Method", "Sample_size", "RMSE")



p1 <- ggplot(data = plot_sd_0, aes(x = Sample_size, y = ESE, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = ESE, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = ESE, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 0.5)) + 
  xlab("") #+ 
  #theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p2 <- ggplot(data = plot_sd_10, aes(x = Sample_size, y = ESE, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = ESE, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = ESE, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 0.5)) + 
  xlab("") + ylab("") #+ 
  #theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p3 <- ggplot(data = plot_sd_20, aes(x = Sample_size, y = ESE, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = ESE, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = ESE, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 0.5)) + 
  xlab("") + ylab("") #+ 
#theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p4 <- ggplot(data = plot_mean_0, aes(x = Sample_size, y = Absolute_value_of_percent_bias, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = Absolute_value_of_percent_bias, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = Absolute_value_of_percent_bias, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 12.5)) + 
  xlab("") #+ 
  #theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p5 <- ggplot(data = plot_mean_10, aes(x = Sample_size, y = Absolute_value_of_percent_bias, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = Absolute_value_of_percent_bias, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = Absolute_value_of_percent_bias, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 2.5)) + 
  xlab("") + ylab("") #+ 
  #theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p6 <- ggplot(data = plot_mean_20, aes(x = Sample_size, y = Absolute_value_of_percent_bias, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = Absolute_value_of_percent_bias, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = Absolute_value_of_percent_bias, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 10)) + 
  xlab("") + ylab("") #+ 
#theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p7 <- ggplot(data = plot_rmse_0, aes(x = Sample_size, y = RMSE, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = RMSE, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = RMSE, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 0.5)) + 
  xlab("")
#theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p8 <- ggplot(data = plot_rmse_10, aes(x = Sample_size, y = RMSE, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = RMSE, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = RMSE, shape = Method, color = Method), size = 3) +
  theme_bw() +
  ylim(c(0, 5.5)) +
  xlab("")
  ylab("") #+ 
#theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))

p9 <- ggplot(data = plot_rmse_20, aes(x = Sample_size, y = RMSE, group = Method, linetype = Method, color = Method)) +
  geom_line(aes(x = Sample_size, y = RMSE, group = Method, linetype = Method, color = Method), linewidth = 1.2) +
  geom_point(aes(x = Sample_size, y = RMSE, shape = Method, color = Method), size = 3) +
  theme_bw() + 
  ylim(c(0, 10.5)) +
  xlab("")
  ylab("") #+ 
#theme(legend.position = c(0.11,0.85), legend.background = element_rect(fill="lightgray"))



p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8 + p9 + 
  plot_layout(guides = "collect", nrow = 3, ncol = 3)　# 凡例を１つにまとめて1列で表示


